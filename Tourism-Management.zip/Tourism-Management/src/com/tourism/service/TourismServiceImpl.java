package com.tourism.service;

import java.util.List;          

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tourism.dao.TourismDAO;
import com.tourism.entity.User;
import com.tourism.entity.Package;

@Service
public class TourismServiceImpl implements TourismService {

	// need to inject user dao
	@Autowired
	private TourismDAO DAO;

	@Override
	@Transactional
	public List<Package> getPackages() {

		return DAO.getPackages();
	}

	@Override
	@Transactional
	public void savePackage(Package thePackage) {

		DAO.savePackage(thePackage);
	}
	
	@Override
	@Transactional
	public Package getPackage(int theId) {
		
		return DAO.getPackage(theId);
	}
	
	@Override
	@Transactional
	public void deletePackage(int theId) {
		
		DAO.deletePackage(theId);
	}

	@Override
	@Transactional
	public List<User> getUsers() {

		return DAO.getUsers();
	}

	@Override
	@Transactional
	public void saveUser(User theUser) {

		DAO.saveUser(theUser);
	}
	
	@Override
	@Transactional
	public User getUser(int theId) {
		
		return DAO.getUser(theId);
	}
	
	@Override
	@Transactional
	public void deleteUser(int theId) {
		
		DAO.deleteUser(theId);
	}
	
}

