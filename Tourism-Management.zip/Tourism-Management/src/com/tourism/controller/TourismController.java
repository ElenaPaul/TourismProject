package com.tourism.controller;

import java.util.List;      

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tourism.entity.User;
import com.tourism.entity.Package;
import com.tourism.service.TourismService;

@Controller
@RequestMapping("/tourism")
public class TourismController {

	// need to inject the user Service
		@Autowired
		private TourismService Service;
	
	@GetMapping("/listpackage")
	public String listPackages(Model theModel) {
		
		// get Packages from the Service
				List<Package> thePackages = Service.getPackages();
						
				// add the Packages to the model
				theModel.addAttribute("packages", thePackages);
		
		return "list-packages";
	}
	
	@GetMapping("/listpackage1")
	public String listPackages1(Model theModel) {
		
		// get Packages from the Service
				List<Package> thePackages = Service.getPackages();
						
				// add the Packages to the model
				theModel.addAttribute("packages", thePackages);
		
		return "list-packages1";
	}
	
	@GetMapping("/addpackage")
	public String addPackage(Model theModel) {
		
		// create model attribute to bind form data
		Package thePackage = new Package();
		
		theModel.addAttribute("package", thePackage);
		
		return "package-form";
	}
	
	@PostMapping("/savePackage")
	public String savePackage(@ModelAttribute("Package") Package thePackage) {
		
		// save the package using our service
		Service.savePackage(thePackage);	
		
		return "redirect:/tourism/listpackage";
	}	
	
	@GetMapping("/updatepackage")
	public String updatePackage(@RequestParam("packageId") int theId,
									Model theModel) {
		
		// get the package from our service
		Package thePackage = Service.getPackage(theId);	
		
		// set package as a model attribute to pre-populate the form
		theModel.addAttribute("package", thePackage);
		
		// send over to our form		
		return "package-form";
	}
	
	@GetMapping("/deletepackage")
	public String deletePackage(@RequestParam("packageId") int theId) {
		
		// delete the package
		Service.deletePackage(theId);
		
		return "redirect:/tourism/listpackage";
	}
	
	@GetMapping("/listuser")
	public String listUsers(Model theModel) {
		
		// get users from the Service
				List<User> theUsers = Service.getUsers();
						
				// add the users to the model
				theModel.addAttribute("users", theUsers);
		
		return "list-users";
	}
	
	@GetMapping("/listuser1")
	public String listUsers1(Model theModel) {
		
		// get users from the Service
				List<User> theUsers = Service.getUsers();
						
				// add the users to the model
				theModel.addAttribute("users", theUsers);
		
		return "list-users1";
	}
	
	@GetMapping("/adduser")
	public String addUser(Model theModel) {
		
		// create model attribute to bind form data
		User theUser = new User();
		
		theModel.addAttribute("user", theUser);
		
		return "user-form";
	}
	
	@PostMapping("/saveUser")
	public String saveUser(@ModelAttribute("User") User theUser) {
		
		// save the package using our service
		Service.saveUser(theUser);	
		
		return "redirect:/tourism/listuser1";
	}	
	
	@GetMapping("/adduser1")
	public String addUser1(Model theModel) {
		
		// create model attribute to bind form data
		User theUser = new User();
		
		theModel.addAttribute("user", theUser);
		
		return "user-form1";
	}
	
	@PostMapping("/saveUser1")
	public String saveUser1(@ModelAttribute("User") User theUser) {
		
		// save the package using our service
		Service.saveUser(theUser);	
		
		return "Payment";
	}	
	
	@GetMapping("/updateuser")
	public String updateUser(@RequestParam("userId") int theId,
									Model theModel) {
		
		// get the User from our service
		User theUser = Service.getUser(theId);	
		
		// set user as a model attribute to pre-populate the form
		theModel.addAttribute("user", theUser);
		
		// send over to our form		
		return "user-form";
	}
	
	@GetMapping("/deleteuser")
	public String deleteUser(@RequestParam("userId") int theId) {
		
		// delete the user
		Service.deleteUser(theId);
		
		return "redirect:/tourism/listuser1";
	}
}



