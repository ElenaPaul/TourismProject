package com.tourism.dao;

import java.util.List;    

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;

import com.tourism.entity.User;
import com.tourism.entity.Package;

@Repository
public class TourismDAOImpl implements TourismDAO {

	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Package> getPackages() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query
		Query<Package> theQuery = 
				currentSession.createQuery("from Package order by packageName", Package.class);

		// execute query and get result list
		List<Package> packages = theQuery.getResultList();

		// return the results		
		return packages;
	}

	
	@Override
	public void savePackage(Package thePackage) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// save/update the package ... finally LOL
		currentSession.saveOrUpdate(thePackage);
		
	}
	
	@Override
	public Package getPackage(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// now retrieve/read from database using the primary key
		Package thePackage = currentSession.get(Package.class, theId);
		
		return thePackage;
	}
	
	@Override
	public void deletePackage(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// delete object with primary key
		Query theQuery = 
				currentSession.createQuery("delete from Package where id=:packageId");
		theQuery.setParameter("packageId", theId);
		
		theQuery.executeUpdate();		
	}
	

	@Override
	public List<User> getUsers() {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();

		// create a query
		Query<User> theQuery = 
				currentSession.createQuery("from User order by package_", User.class);

		// execute query and get result list
		List<User> users = theQuery.getResultList();

		// return the results		
		return users;

	}
	
	@Override
	public void saveUser(User theUser) {

		// get current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// save/update the package ... finally LOL
		currentSession.saveOrUpdate(theUser);
		
	}
	
	@Override
	public User getUser(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// now retrieve/read from database using the primary key
		User theUser = currentSession.get(User.class, theId);
		
		return theUser;
	}
	
	@Override
	public void deleteUser(int theId) {

		// get the current hibernate session
		Session currentSession = sessionFactory.getCurrentSession();
		
		// delete object with primary key
		Query theQuery = 
				currentSession.createQuery("delete from User where id=:userId");
		theQuery.setParameter("userId", theId);
		
		theQuery.executeUpdate();		
	}
	
	
}






