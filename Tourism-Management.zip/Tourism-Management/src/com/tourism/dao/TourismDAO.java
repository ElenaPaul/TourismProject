package com.tourism.dao;

import java.util.List;         

import com.tourism.entity.User;
import com.tourism.entity.Package;

public interface TourismDAO {

	public List<Package> getPackages();

	public void savePackage(Package thePackage);

	public Package getPackage(int theId);

	public void deletePackage(int theId);

	public List<User> getUsers();

	public void saveUser(User theUser);

	public User getUser(int theId);

	public void deleteUser(int theId);

}
