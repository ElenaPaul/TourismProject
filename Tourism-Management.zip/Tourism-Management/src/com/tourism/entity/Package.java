package com.tourism.entity;

import javax.persistence.Column;     
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="package")
public class Package {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="Package_Place")
	private String packageName;
	
	@Column(name="No_of_days")
	private String noofDays;
	
	@Column(name="Amount")
	private int amount;
	
	public Package() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getNoofDays() {
		return noofDays;
	}

	public void setNoofDays(String noofDays) {
		this.noofDays = noofDays;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Package [id=" + id + ", packageName=" + packageName + ", noofDays=" + noofDays + ", amount=" + amount
				+ "]";
	}
	
	
}