create database elena;
use elena;
create database tourism;
use tourism;

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` integer(11) NOT NULL AUTO_INCREMENT,
  `First_name` varchar(45) DEFAULT NULL,
  `Last_name` varchar(45) DEFAULT NULL,
  `Email_Id` varchar(45) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `Package` varchar(45) DEFAULT NULL,
  `Boarding` varchar(45) DEFAULT NULL,
  `Date_of_Travel` date DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;

INSERT INTO `user` VALUES 
	(1,'Dawny','Joy','dawny@tourism.com',9876543210,'Goa','Kochi','2020-04-25','dawny'),
	(2,'Amal','Sathyan','amal@tourism.com',9865327410,'Hyderabad','Kannur','2020-04-30','amal'),
	(3,'Elena','Paul','elena@tourism.com',9638527410,'Kerala','Thrissur','2020-04-22','elena');

INSERT INTO `user` VALUES 
	(4,'Susan','Jain','susan@tourism.com',9876545510,'Goa','Vytila','2020-04-28','susan');

UNLOCK TABLES;
select *from user;

use tourism;

DROP TABLE IF EXISTS `package`;

CREATE TABLE `package` (
  `id` integer(11) NOT NULL AUTO_INCREMENT,
  `Package_Place` varchar(45) DEFAULT NULL,
  `No_of_days` varchar(45) DEFAULT NULL,
  `Amount` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

LOCK TABLES `package` WRITE;

INSERT INTO `package` VALUES 
	(1,'Mysore','4 days and 3 nights','4500'),
	(2,'Goa','3 days and 2 nights','5000'),
	(3,'Kerala','5 days and 4 nights','8000'),
    (4,'Hyderabad','4 days and 3 nights','8500');

UNLOCK TABLES;
select *from package;
use tourism;
drop table tourmanager;
create table tourmanager(username varchar(30), password varchar(30));
insert into tourmanager values('Manager','Mngr@123');
select *from tourmanager;

create table touroperator(username varchar(30), password varchar(30));
insert into touroperator values('Operator','Optr@123');
select *from touroperator;


